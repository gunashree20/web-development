const quizData = [
 {q:"Which technology translates a domain name into IP information?",a:["HTTP","DNS","TCP","FTP"],correct:1,why:"DNS resolves domain names by returning records such as A (IPv4) and AAAA (IPv6)."},
 {q:"How many bits are used by an IPv4 address?",a:["16 bits","32 bits","64 bits","128 bits"],correct:1,why:"IPv4 uses 32 bits, represented as four 8-bit decimal octets."},
 {q:"Which transport protocol provides reliable, ordered delivery?",a:["UDP","IP","TCP","ARP"],correct:2,why:"TCP uses sequence numbers, acknowledgements and retransmissions to provide a reliable ordered byte stream."},
 {q:"Which port is commonly used by HTTPS?",a:["80","21","443","53"],correct:2,why:"HTTPS commonly uses port 443. HTTP/3 uses QUIC over UDP on port 443."},
 {q:"IPv6 addresses are how many bits long?",a:["32","64","96","128"],correct:3,why:"IPv6 uses 128-bit addresses, giving it a vastly larger address space than IPv4."},
 {q:"What are the TCP three-way handshake messages?",a:["GET, POST, PUT","SYN, SYN-ACK, ACK","DNS, HTTP, TLS","START, SEND, END"],correct:1,why:"The client sends SYN, the server replies SYN-ACK, and the client completes the handshake with ACK."},
 {q:"Which HTTP method is commonly used to retrieve data?",a:["GET","POST","DELETE","PATCH"],correct:0,why:"GET requests a representation of a resource and is commonly used to retrieve data."},
 {q:"Which OSI layer is associated with IP routing?",a:["Application","Transport","Network","Physical"],correct:2,why:"The OSI Network layer (Layer 3) handles logical addressing and routing; IP operates at this layer."}
];
const quizContainer = document.getElementById("quizContainer");
function renderQuiz(){
 quizContainer.innerHTML = quizData.map((q,i)=>`<div class="quiz-question" data-question="${i}"><h3>${i+1}. ${q.q}</h3>${q.a.map((option,j)=>`<label class="quiz-option"><input type="radio" name="q${i}" value="${j}"> ${option}</label>`).join("")}<div class="feedback-slot"></div></div>`).join("");
 document.getElementById("quizResult").innerHTML="";
}
document.getElementById("submitQuiz").addEventListener("click",()=>{
 let score=0,answered=0;
 quizData.forEach((q,i)=>{
  const selected=document.querySelector(`input[name="q${i}"]:checked`);
  const slot=document.querySelector(`[data-question="${i}"] .feedback-slot`);
  if(selected) answered++;
  const good=selected && Number(selected.value)===q.correct;
  if(good) score++;
  slot.innerHTML=`<div class="quiz-feedback ${good?"correct":"incorrect"}"><b>${good?"Correct!":"Review this answer."}</b> ${q.why}${!good?` Correct answer: <b>${q.a[q.correct]}</b>.`:""}</div>`;
 });
 const result=document.getElementById("quizResult");
 result.innerHTML=`<div class="alert alert-primary"><b>Your score: ${score} / ${quizData.length}</b><br>You answered ${answered} of ${quizData.length} questions. ${score===quizData.length?"Excellent work!":score>=5?"Good effort — review the explanations for any missed questions.":"Revisit the notes and try again."}</div>`;
});
document.getElementById("resetQuiz").addEventListener("click",renderQuiz);
renderQuiz();

document.querySelectorAll("[data-copy]").forEach(button=>{
 button.addEventListener("click",async()=>{
  try{await navigator.clipboard.writeText(button.dataset.copy);const old=button.textContent;button.textContent="Copied!";setTimeout(()=>button.textContent=old,1400);}
  catch(e){button.textContent="Copy unavailable";}
 });
});
const backToTop=document.getElementById("backToTop");
window.addEventListener("scroll",()=>{backToTop.style.display=window.scrollY>450?"grid":"none";});
backToTop.addEventListener("click",()=>window.scrollTo({top:0,behavior:"smooth"}));
