# Computer Networking — Beginner's Complete Notes

## Files
- `index.html` — complete notes website
- `assets/style.css` — custom responsive styling
- `assets/script.js` — interactive quiz, copy command buttons, back-to-top
- `assets/*.svg` — locally stored networking diagrams and illustrations

## Run
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. Internet access is needed for the Bootstrap CDN, Bootstrap Icons and Google Fonts. The notes and SVG diagrams are stored locally.

## Customization
- Edit the text in `index.html`.
- Change colours and layout in `assets/style.css`.
- Update quiz questions in `assets/script.js`.
- Replace or edit the SVG diagrams in `assets/`.

The website is responsive and uses Bootstrap 5.3.3.


## Mevi Technologies branding
This version includes the supplied Mevi Technologies logo and brand styling.
- Logo: `assets/mevi-logo.png`
- Brand palette: navy, magenta, cyan and yellow inspired by the supplied logo.
- Header and footer identify Mevi Technologies LLP.
- Website: https://mevitechnologies.com

Open `index.html` with VS Code Live Server. Bootstrap, Bootstrap Icons and Google Fonts use CDNs.
